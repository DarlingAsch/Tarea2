﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio
{
    internal class clsMenu
    {
        public static int opcion;
        public static void menu()
        {
            clsProducto Articulo = new clsProducto();
            try
            {
                do
                {
                    Console.WriteLine("1. Agregar Productos");
                    Console.WriteLine("2. Venta de Productos");
                    Console.WriteLine("3. Actualizar Productos");
                    Console.WriteLine("4. Consulta");
                    Console.WriteLine("5. Borrar Precio");
                    Console.WriteLine("6. Reportar");
                    Console.WriteLine("7. Salir");
                    Console.WriteLine("Digite una opción...");
                    opcion = int.Parse(Console.ReadLine());

                    switch (opcion)
                    {
                        case 1: Articulo.Agregar(); break;
                        case 2: Console.WriteLine("opcion 2"); break;
                        case 3: clsProducto.Actualizar(); break;
                        case 4: clsProducto.Consulta(); break;
                        case 5: Console.WriteLine("opcion 5"); break;
                        case 6: clsProducto.Reporte(); break;
                        default:
                            Console.WriteLine("Opcion incorrecta");

                            break;


                    }
                } while (opcion != 7);
            }
            catch (Exception ex)
            {

               Console.WriteLine("Digito mal el codigo" + ex);
            }
            
        }
    }
}
