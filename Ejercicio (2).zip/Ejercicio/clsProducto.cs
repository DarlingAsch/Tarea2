﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio
{
    public class clsProducto
    {
        public int Codigo;
        public string Descripcion;
        public int Existencia;
        public int Minimo;
        public float Precio;
        public static List<clsProducto> producto = new List<clsProducto> ();
        public clsProducto(int codigo, string descripcion, int existencia, int minimo, float precio)
        {
            Codigo = codigo;
            Descripcion = descripcion;
            Existencia = existencia;
            Minimo = minimo;
            Precio = precio;

            
        }
        public clsProducto() { }
        public static void Consulta()
        {
            int cod = 0;
            Boolean existe = false;
            Console.WriteLine("Digite el codigo del producto");
            cod = Convert.ToInt32(Console.ReadLine());

            foreach (var item in producto)
            {
                if (item.Codigo.Equals(cod))
                {
                    Console.WriteLine($"Codigo :{item.Codigo} Descripcion:  {item.Descripcion} Existencia {item.Existencia} Minimo :{item.Minimo} Precio: {item.Precio}");
                    existe = true;
                    break;
                }
            }
            if (!existe)
            {
                Console.Clear();
                Console.WriteLine("El articulo no existe");
            }
            Console.Read();
        }

        public static void Actualizar()
        {
            int cod = 0;
            Boolean existe = false;

            Console.WriteLine("Digite el codigo del producto");
            cod = Convert.ToInt32(Console.ReadLine());


            for (int i = 0; i < producto.Count; i++)
            {
                if (cod == producto[i].Codigo)
                {
             
                    Console.WriteLine("Digite la descripción");
                    producto[i].Descripcion = Console.ReadLine();
                    Console.WriteLine("Digite la existencia");
                    producto[i].Existencia = int.Parse(Console.ReadLine());
                    Console.WriteLine("Digite el mínimo");
                    producto[i].Minimo = int.Parse(Console.ReadLine());
                    Console.WriteLine("Digite el precio");
                    producto[i].Precio = float.Parse(Console.ReadLine());
                    existe = true;
                    break;
                }
            }
            if (!existe)
            {
                Console.Clear();
                Console.WriteLine("El articulo no existe");
            }
            

        }

            public static void Reporte()
        {
            Console.WriteLine("Reporte de articulos");
            foreach (var item in producto)
            {
                Console.WriteLine($"Codigo: {item.Codigo} Descripcion:  {item.Descripcion} Existencia: {item.Existencia} Minimo: {item.Minimo} Precio: {item.Precio}");
            }
        }




        public void Agregar()
        {
            Boolean fin = true;
            do
            {
                Console.WriteLine("Digite el código");
                int cod = int.Parse(Console.ReadLine());
                Console.WriteLine("Digite la descripción");
                string descripcion = Console.ReadLine();
                Console.WriteLine("Digite la existencia");
                int existencia = int.Parse(Console.ReadLine());
                Console.WriteLine("Digite el mínimo");
                int minimo = int.Parse(Console.ReadLine());
                Console.WriteLine("Digite el precio");
                float precio = float.Parse(Console.ReadLine());
                Console.Clear();
                Console.WriteLine("Producto ha sido ingresado");
                Console.WriteLine("Desea ingresar otro producto");
                string n = Console.ReadLine();


                producto.Add(new clsProducto(Codigo= cod, Descripcion=descripcion,Existencia=  existencia,Minimo= minimo,Precio= precio));
                if (n.Equals("n")) fin = false;
                
            } while (fin);



            //producto.Add(new clsProducto(cod, descripcion, existencia, minimo, precio));

            Console.WriteLine("Elementos de la lista");
            foreach (var item in producto)
            {
                Console.WriteLine($"Codigo: {item.Codigo} Descripcion:  {item.Descripcion} Existencia: {item.Existencia} Minimo: {item.Minimo} Precio: {item.Precio}");
            }
        }

        

    }
        
}
