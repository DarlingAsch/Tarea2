﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio
{
    internal class Program
    {
        static void Main(string[] args)
        {
           clsProducto articulo = new clsProducto(1, "Mesa de oficina", 25,5,5000);
            Console.WriteLine(articulo.Codigo + " " + articulo.Descripcion);
            clsMenu.menu();

            Console.Read();
        }
    }
}
